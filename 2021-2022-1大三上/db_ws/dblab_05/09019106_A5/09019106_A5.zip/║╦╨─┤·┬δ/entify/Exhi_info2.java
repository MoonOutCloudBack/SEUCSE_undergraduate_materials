package entify;

public class Exhi_info2 {
    private String eid;
    private String ename;
    private String start_date; // 必须遵守yyyy-MM-dd的格式，下同
    private String end_date;
    private String eintro;
    private String epicture;
    private String mid;

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid;
    }

    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_date) {
        this.start_date = start_date;
    }

    public String getEnd_date() {
        return end_date;
    }

    public void setEnd_date(String end_date) {
        this.end_date = end_date;
    }

    public String getEintro() {
        return eintro;
    }

    public void setEintro(String eintro) {
        this.eintro = eintro;
    }

    public String getEpicture() {
        return epicture;
    }

    public void setEpicture(String epicture) {
        this.epicture = epicture;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }
}
