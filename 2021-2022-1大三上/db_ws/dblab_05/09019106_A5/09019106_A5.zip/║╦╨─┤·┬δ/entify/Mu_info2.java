package entify;

public class Mu_info2 {
    private String mid;
    private String mname;
    private String mintro;
    private String mpicture;
    private String city;

    public String getMid() {
        return mid;
    }

    public String getMname() {
        return mname;
    }

    public String getMintro() {
        return mintro;
    }

    public String getMpicture() {
        return mpicture;
    }

    public String getCity() {
        return city;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public void setMintro(String mintro) {
        this.mintro = mintro;
    }

    public void setMpicture(String mpicture) {
        this.mpicture = mpicture;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
