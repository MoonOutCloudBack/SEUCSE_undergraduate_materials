package entify;

public class Trea_info {
    private String tid;
    private String tname;
    private String mid;

    public String getTid() {
        return tid;
    }

    public String getTname() {
        return tname;
    }

    public String getMid() {
        return mid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }
}
