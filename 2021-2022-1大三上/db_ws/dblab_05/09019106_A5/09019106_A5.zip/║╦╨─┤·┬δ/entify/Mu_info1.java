package entify;

public class Mu_info1 {
    private String mid;
    private String mname;

    public  String getMid(){return mid;}

    public String getMname(){return mname;}

    public void setMid(String mid){this.mid=mid;}


    public void setMname(String mname){this.mname=mname;}

}
